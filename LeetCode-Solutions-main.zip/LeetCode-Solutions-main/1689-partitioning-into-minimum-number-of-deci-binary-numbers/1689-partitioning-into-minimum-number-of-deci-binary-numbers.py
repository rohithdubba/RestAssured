class Solution:
    def minPartitions(self, n: str) -> int:
        return max(n)